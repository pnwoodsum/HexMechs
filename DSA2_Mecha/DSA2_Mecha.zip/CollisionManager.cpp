#include "CollisionManager.h"

CollisionManager* CollisionManager::instance = nullptr;