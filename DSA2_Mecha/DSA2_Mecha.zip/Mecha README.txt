Current Controls:

Mouse to move Camera

WASD to move

F to shoot

Shift + WASD to boost... kind of